const navbarToggler = document.querySelector('.navbar-toggler');
const navbarMenu = document.querySelector('.navbar ul');
const navbarLinks = document.querySelectorAll('.navbar a');
navbarToggler.addEventListener('click', navbarTogglerClick);
function navbarTogglerClick() {
  navbarToggler.classList.toggle('open-navbar-toggler');
  navbarMenu.classList.toggle('open');
}
navbarLinks.forEach((elem) => elem.addEventListener('click', navbarLinkClick));
function navbarLinkClick() {
  if (navbarMenu.classList.contains('open')) {
    navbarToggler.click();
  }
}
// Popup Al
var modal = document.getElementById('myModal');

// Kipi açan düğmeyi al
var btn = document.getElementById('myBtn');

// Kipi kapatan <span> öğesini edinin
var span = document.getElementsByClassName('close')[0];

// Kullanıcı düğmeyi tıklattığında
btn.onclick = function () {
  modal.style.display = 'block';
};

// Kullanıcı <span> (x) düğmesini tıkladığında, popup
span.onclick = function () {
  modal.style.display = 'none';
};

// Kullanıcı modelden başka herhangi bir yeri tıklattıysa, onu kapatın.
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = 'none';
  }
};

var template = $('#form_rows_tpl').html(),
  $target = $('.dynamic-rows'),
  $btnAdd = $('button.add'),
  $btnRemove = $('button.remove'),
  $msg = $('.msg'),
  max = 10,
  count = 1,
  inputRow = [];

$btnAdd.click(function (e) {
  e.preventDefault();
  addRows();
});

$btnRemove.click(function (e) {
  e.preventDefault();
  removeRows();
});

function addRows() {
  if (count <= max) {
    inputRow = {
      count: count,
    };
    var html = Mustache.to_html(template, inputRow);
    $target.append(html);
    count++;
  } else {
    $msg.text('too many fields!');
  }
}

function removeRows() {
  $target.find('.row').last().remove();
  $msg.text('');
  if (count <= 1) {
    count = 1;
  } else {
    count--;
  }
}

addRows();

$(function () {
  $('.material-card > .mc-btn-action').click(function () {
    var card = $(this).parent('.material-card');
    var icon = $(this).children('i');
    icon.addClass('fa-spin-fast');

    if (card.hasClass('mc-active')) {
      card.removeClass('mc-active');

      window.setTimeout(function () {
        icon.removeClass('fa-arrow-left').removeClass('fa-spin-fast').addClass('fa-bars');
      }, 800);
    } else {
      card.addClass('mc-active');

      window.setTimeout(function () {
        icon.removeClass('fa-bars').removeClass('fa-spin-fast').addClass('fa-arrow-left');
      }, 800);
    }
  });
});
